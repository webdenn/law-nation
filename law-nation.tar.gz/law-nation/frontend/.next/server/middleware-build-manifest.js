globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/904ffa35078748c2.js",
    "static/chunks/96cfc69569c05097.js",
    "static/chunks/0b946c6bc752f65f.js",
    "static/chunks/8de8d219188b8b79.js",
    "static/chunks/b3efd27c11bbeba0.js",
    "static/chunks/turbopack-ba10d7a4e0d5d18f.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];