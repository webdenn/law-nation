module.exports=[19046,(e,o,d)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app_favicon_ico_route_actions_592ed0d4.js.map