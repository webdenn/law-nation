module.exports=[86846,a=>{a.v("/law/_next/static/media/favicon.0b3bf435.ico")},77595,a=>{"use strict";let b={src:a.i(86846).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=law-nation_frontend_app_5d924896._.js.map