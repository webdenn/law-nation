module.exports=[25480,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_forgot-password_page_actions_88c88908.js.map