module.exports=[52129,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28dashboard%29_reviewer_page_actions_b46369a6.js.map