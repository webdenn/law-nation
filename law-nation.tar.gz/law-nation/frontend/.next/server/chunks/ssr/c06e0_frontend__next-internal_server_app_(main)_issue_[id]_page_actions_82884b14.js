module.exports=[92117,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_issue_%5Bid%5D_page_actions_82884b14.js.map