module.exports=[41218,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_reset-password_page_actions_4c095953.js.map