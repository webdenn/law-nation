module.exports=[24707,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_articles_page_actions_ba65fb80.js.map