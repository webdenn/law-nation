module.exports=[1893,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app__global-error_page_actions_a8989ca7.js.map