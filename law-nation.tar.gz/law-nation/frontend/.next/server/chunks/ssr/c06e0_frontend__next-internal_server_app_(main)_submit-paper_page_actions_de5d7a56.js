module.exports=[29751,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_submit-paper_page_actions_de5d7a56.js.map