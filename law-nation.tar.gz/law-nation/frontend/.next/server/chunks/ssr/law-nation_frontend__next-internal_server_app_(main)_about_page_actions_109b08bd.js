module.exports=[23489,(a,b,c)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app_%28main%29_about_page_actions_109b08bd.js.map