module.exports=[2127,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28dashboard%29_editor_page_actions_5ee015c3.js.map