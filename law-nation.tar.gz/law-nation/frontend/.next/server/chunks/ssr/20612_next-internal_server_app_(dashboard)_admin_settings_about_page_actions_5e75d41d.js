module.exports=[32355,(a,b,c)=>{}];

//# sourceMappingURL=20612_next-internal_server_app_%28dashboard%29_admin_settings_about_page_actions_5e75d41d.js.map