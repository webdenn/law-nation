module.exports=[44034,(a,b,c)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app_%28main%29_login_page_actions_0899052f.js.map