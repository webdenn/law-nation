module.exports=[36201,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_setup-password_page_actions_77e18053.js.map