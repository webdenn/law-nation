module.exports=[21355,(a,b,c)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app_%28main%29_home_page_actions_1da9ce73.js.map