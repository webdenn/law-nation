module.exports=[1610,(a,b,c)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app__not-found_page_actions_1b665085.js.map