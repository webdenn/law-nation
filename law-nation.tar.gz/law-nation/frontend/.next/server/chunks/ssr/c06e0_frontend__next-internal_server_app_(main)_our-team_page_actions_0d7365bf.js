module.exports=[11439,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_our-team_page_actions_0d7365bf.js.map