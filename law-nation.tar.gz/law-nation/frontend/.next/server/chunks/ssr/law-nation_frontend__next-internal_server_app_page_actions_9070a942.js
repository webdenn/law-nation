module.exports=[72627,(a,b,c)=>{}];

//# sourceMappingURL=law-nation_frontend__next-internal_server_app_page_actions_9070a942.js.map