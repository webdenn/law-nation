module.exports=[44587,(a,b,c)=>{}];

//# sourceMappingURL=8c5b4__next-internal_server_app_%28dashboard%29_admin_staff_page_actions_4595d2d6.js.map