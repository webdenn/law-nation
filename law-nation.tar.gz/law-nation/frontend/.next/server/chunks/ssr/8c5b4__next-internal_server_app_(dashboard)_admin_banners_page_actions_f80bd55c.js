module.exports=[61862,(a,b,c)=>{}];

//# sourceMappingURL=8c5b4__next-internal_server_app_%28dashboard%29_admin_banners_page_actions_f80bd55c.js.map