module.exports=[16898,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28dashboard%29_admin_page_actions_e8f2e69d.js.map