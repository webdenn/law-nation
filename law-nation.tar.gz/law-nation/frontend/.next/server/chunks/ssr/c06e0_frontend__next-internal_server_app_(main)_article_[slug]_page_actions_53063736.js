module.exports=[52169,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_article_%5Bslug%5D_page_actions_53063736.js.map