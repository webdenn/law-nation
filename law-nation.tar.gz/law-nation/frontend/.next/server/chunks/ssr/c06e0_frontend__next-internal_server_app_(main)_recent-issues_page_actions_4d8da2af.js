module.exports=[81090,(a,b,c)=>{}];

//# sourceMappingURL=c06e0_frontend__next-internal_server_app_%28main%29_recent-issues_page_actions_4d8da2af.js.map