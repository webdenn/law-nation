var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__75572ba8._.js")
R.c("server/chunks/law-nation_frontend__next-internal_server_app_favicon_ico_route_actions_592ed0d4.js")
R.m(94159)
module.exports=R.m(94159).exports
